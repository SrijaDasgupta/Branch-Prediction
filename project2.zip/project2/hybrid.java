//creating hybrid class
import java.util.*;
public class hybrid {
	
	List<String> dataList;
	
	int mispred,counter,hist_reg_val,bimodal_index,gshare_index,hybrid_index,k,m1,n,m2;
	int array[],gshare[],bimodal[];
	
	public void input() {
		// TODO Auto-generated method stub
		
		for(int i=0; i<this.dataList.size(); i++)
		{
			String dataPoint = this.dataList.get(i);
			
			counter++;
			
			int index1 = Integer.parseInt(dataPoint.split(" ")[0],16);
			int bimodalIndex = index1 >> 2;
		    bimodalIndex = bimodalIndex & (int)(Math.pow(2, m2) -1);
		   
			
			boolean bimodal_Correct = (bimodal[bimodalIndex]>=4?"t":"n").equals(dataPoint.split(" ")[1]);
			
			int index2 = Integer.parseInt(dataPoint.split(" ")[0],16);
			int gshareIndex = index2 >> 2;
			gshareIndex = gshareIndex & (int)(Math.pow(2, m1) -1);
			gshareIndex = hist_reg_val ^ gshareIndex;
			
			
			
			hist_reg_val >>= 1;
			if(dataPoint.split(" ")[1].equals("t")) {
				hist_reg_val = hist_reg_val | (int)Math.pow(2, n-1);
			}
			
			boolean gshare_Correct = (gshare[gshareIndex]>=4?"t":"n").equals(dataPoint.split(" ")[1]);
			
			int index3 = Integer.parseInt(dataPoint.split(" ")[0],16);
			int hybridIndex  = index3 >> 2;
			hybridIndex  = hybridIndex  & (int)(Math.pow(2, k) -1);
			
			
			
			
			if(array[hybridIndex] >= 2)
			{
				if(!gshare_Correct)
					mispred++;
				
				if(dataPoint.split(" ")[1].equals("t")) {
					if(gshare[gshareIndex] < 7)
						gshare[gshareIndex]++;
				}
				else 
					{
						if(gshare[gshareIndex] > 0)
							gshare[gshareIndex]--;
					}
						
			}
			else {
				if(!bimodal_Correct)
					mispred++;
				
				if(dataPoint.split(" ")[1].equals("t")) {
					if(bimodal[bimodalIndex] < 7)
						bimodal[bimodalIndex]++;
				}
				else 
					{
						if(bimodal[bimodalIndex] > 0)
							bimodal[bimodalIndex]--;
					}
			}
						
			
			
			if(bimodal_Correct && !gshare_Correct && array[hybridIndex] > 0)
				array[hybridIndex]--;
			else if(!bimodal_Correct && gshare_Correct && array[hybridIndex] < 3)
				array[hybridIndex]++;
			
			
		}
		
	}
	
	public hybrid(int k, int m1, int n, int m2, List<String> dataList) {
		super();
		this.k = k;
		this.m1 = m1;
		this.n = n;
		this.m2 = m2;
		this.dataList = dataList;
		
		array = new int[(int)Math.pow(2, k)];
		gshare = new int[(int)Math.pow(2, m1)];
		bimodal = new int[(int)Math.pow(2, m2)];
		
		Arrays.fill(array, 1);
		Arrays.fill(gshare, 4);
		Arrays.fill(bimodal, 4);
	
		input();
	
		
		System.out.println("number of predictions:		"+counter);//calculating counters
		System.out.println("number of mispredictions:	"+mispred);//calculating number of mispredictions
		System.out.println("misprediction rate:		"+String.format("%.2f", ((double)mispred/(double)counter)*100)+"%");
		//calculating misprediction rate
		System.out.println("FINAL CHOOSER CONTENTS");
		for(int i=0; i<array.length; i++)
		{
			System.out.println(i+"	"+array[i]);
		}
		System.out.println("FINAL GSHARE CONTENTS");
		for(int i=0; i<gshare.length; i++)
		{
			System.out.println(gshare[i] + "  " + i);
		}
		System.out.println("FINAL BIMODAL CONTENTS");
		for(int i=0; i<bimodal.length; i++)
		{
			System.out.println(bimodal[i]+"	 "+i);
		}
		
	}
	
	
	
	

	
	
}
