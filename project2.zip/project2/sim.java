//creating sim class
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class sim {

	public static void main(String[] args) {
		
			if(args[0].equals("smith"))
			{
				List<String> list=readFile(args[2]);
				new smith(list,Integer.parseInt(args[1]));
			}

			if(args[0].equals("bimodal"))
			{
				List<String> list=readFile(args[2]);
				new gshare(Integer.parseInt(args[1]), 0, list);
			}

			if(args[0].equals("gshare"))
			{
				List<String> list=readFile(args[3]);
				new gshare(Integer.parseInt(args[1]), Integer.parseInt(args[2]), list);
			}

			if(args[0].equals("hybrid"))
			{
				List<String> list=readFile(args[5]);
				new hybrid(Integer.parseInt(args[1]), Integer.parseInt(args[2]),Integer.parseInt(args[3]),Integer.parseInt(args[4]),list);
			}

		
	}

	
	private static List<String> readFile(String fileName) {
		// TODO Auto-generated method stub
		
		List<String> li = new ArrayList<>();
		
		File inFile = new File(fileName);
		
		  BufferedReader br = null;
	
	       try {
	
	           String sCurrentLine;
	
	           br = new BufferedReader(new FileReader(inFile));
	
	           while ((sCurrentLine = br.readLine()) != null) {
	               li.add(sCurrentLine);
	           }
	
	       } 
	
	       catch (IOException e) {
	           e.printStackTrace();
	       } 
	
	       finally {
	           try {
	               if (br != null)br.close();
	           } catch (IOException ex) {
	               ex.printStackTrace();
	           }
	       }
		return li;
	}


	
}



