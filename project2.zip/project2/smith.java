//creating smith class
import java.util.*;

public class smith {
	int prediction;
	
	
	int limit,counter,mispred;
	List<String> dataList;
	int bits;
	public smith(List<String> dataList, int bits) {
		super();
		this.dataList = dataList;
		this.bits = bits;
		
		//calculating bits
		if (bits == 1)
			limit=counter=1;
		else if(bits == 2)
			limit=counter=2;
		else if(bits == 3)
			limit=counter=4;
		else if(bits==4)
			limit=counter=8;
		else
			limit=counter=(int)Math.pow(2, bits-1);
		
		input();
		
		System.out.println("The number of predictions:" + dataList.size());//calculating no of predictions
		System.out.println("The number of miss predictions:" +mispred);//caclculating number of mispredictions
		System.out.println("Misprediction Rate: " + String.format("%.2f", ((double)mispred/(double)dataList.size())*100)+"%");//misprediction rate
		System.out.println("Final Counter Content" +counter);//calculating counter
	}
	private void input() {
		for(int i=0;i<dataList.size();i++)
		{
			String s=dataList.get(i).split(" ")[1];
			
			
			String predicted="";
			if(counter>=limit)
			{
				predicted="t";
			}
			else
				predicted="n";
			
			if(!s.equals(predicted))
			{
				mispred++;
			}
			
			
				
			
			if(s.charAt(0)=='t')
			{
				
				
				int temp=(int)Math.pow(2, bits)-1;
				if(counter<temp)
					counter++;
				
			}
			else {
				if(counter>0)
				{
					counter--;
				}
			}
		}
		
	}
	
	
}
