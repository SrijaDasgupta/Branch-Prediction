//creating gshare class
import java.util.*;
public class gshare {
	
	List<String> dataList;
	boolean temp = false;
	int array[];
	int m,n,mispred,counter,hit_reg_val;
	private void input() {
		// TODO Auto-generated method stub
		for(int i=0; i<this.dataList.size(); i++)
		{
			String dataPoint = this.dataList.get(i);
			
			counter++;
			
			int counter = getCounter(Integer.parseInt(dataPoint.split(" ")[0],16));
			
			if(!(array[counter]>=4?"t":"n").equals(dataPoint.split(" ")[1])) 
				mispred++;
			
			if(dataPoint.split(" ")[1].equals("t"))
				{if(array[counter]<7)
				{
					array[counter]++;
				}}
			else
				{if(array[counter]>0)
				{
					array[counter]--;
				}
				}
			
			
			if(temp) {
				
				hit_reg_val >>= 1;
		
				if(dataPoint.split(" ")[1].equals("t")) {
					hit_reg_val = hit_reg_val | (int)Math.pow(2, n-1);
				}
			}
		}
		
	}
	
	public gshare(int m, int n, List<String> dataList) {
		
		
		this.m = m;
		this.n = n;
		this.dataList = dataList;
		
		array = new int[(int)Math.pow(2, m)];
		Arrays.fill(array, 4);
		
		hit_reg_val = 0;
		if(n!=0)
			temp = true;
		
		input();
		

		
		System.out.println("number of predictions:		"+counter);//calculating counter
		System.out.println("number of mispredictions:	"+mispred);//caclculating number of mispredictions
		System.out.println("misprediction rate:		"+String.format("%.2f", ((double)mispred/(double)counter)*100)+"%");//misprediction rate
		if(temp)
			System.out.println("FINAL GSHARE CONTENTS");
		else
			System.out.println("FINAL BIMODAL CONTENTS");
		
		for(int i=0; i<array.length; i++)
		{
			System.out.println(i+"	"+array[i]);
		}
		
	}
	
	
	private int getCounter(int data) {
		// TODO Auto-generated method stub
		int counter = data >> 2;
		counter = counter & (int)(Math.pow(2, m) -1);
		if(temp)
		{
			counter = hit_reg_val ^ counter;
		}
		
		return counter;
		
		
	}
	
	
	
	
	
	
}
